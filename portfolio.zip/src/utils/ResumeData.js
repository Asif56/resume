// import React from 'react';
import FacebookIcon from '@material-ui/icons/Facebook';
import TwitterIcon from '@material-ui/icons/Twitter';
import LinkedInIcon from '@material-ui/icons/LinkedIn';
import GitHubIcon from '@material-ui/icons/GitHub';
import WebOutlinedIcon from '@material-ui/icons/WebOutlined';
import AssessmentOutlinedIcon from '@material-ui/icons/AssessmentOutlined';
import { YouTube } from '@material-ui/icons';
import LanguageIcon from '@material-ui/icons/Language';


export default {
    name: 'Sam is Coding',
    title: 'Full hdhfhs',
    
    birthday: 'bhdbh bdhd dvfh',
    email: 'bhbfbdvdhh',
    address: 'bdhvgdhhd',
    phone: 'hbvhfbvhbd',

    socials: {
        facebook: {
            link: 'vbdbvhdbzvhavshv',
            text: 'text',
            icon: <FacebookIcon />,
        },
        Twitter: {
            link: 'vbdbvhdbzvhavshv',
            text: 'text',
            icon: <TwitterIcon />,
        },
        LinkedIn: {
            link: 'vbdbvhdbzvhavshv',
            text: 'text',
            icon: <LinkedInIcon />,
        },
        Github: {
            link: 'vbdbvhdbzvhavshv',
            text: 'text',
            icon: <GitHubIcon />,
        },


    },
    about: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, \n\n but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",
    
    experiance:[
        {
            title:'vbhvn',
            date:'bhdfvfg',
            description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make "
        },
        {
            title:'vbhvn',
            date:'bhdfvfg',
            description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make "
        },
        {
            title:'vbhvn',
            date:'bhdfvfg',
            description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make "
        },
    ],

    education:[
        {
            title:'vbhvn',
            date:'bhdfvfg',
            description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make "
        },
        {
            title:'vbhvn',
            date:'bhdfvfg',
            description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make "
        },
        {
            title:'vbhvn',
            date:'bhdfvfg',
            description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make "
        },
    ],
    service:[
        {
            title:"bvhhvbh",
            description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ',
            icon:<WebOutlinedIcon/>
        },
        {
            title:"bvhhvbh",
            description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ',
            icon:<AssessmentOutlinedIcon/>
        },
        {
            title:"bvhhvbh",
            description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ',
            icon:<WebOutlinedIcon/>
        },
    ],
    skill:[
        {
            title:'FRONT-END',
            description:[
              "React.js",
              "React.js","React.js","React.js","React.js"
            ],
            
        },
        {
            title:'BECK-END',
            description:[
             'React.js',
             'React.js',
             'React.js',
             'React.js',
             'React.js'
            ],
            
        },
        {
            title:'dATABASE',
            description:[
             'React.js',
             'React.js',
             'React.js',
             'React.js',
             'React.js'
            ],
            
        },
        {
            title:'source contorl',
            description:[
             'React.js',
             'React.js',
             'React.js',
             'React.js',
             'React.js'
            ],
            
        }
    ],
    projects:[
        {
            tag:"react",
            image:"https://i.pinimg.com/564x/6f/d6/8c/6fd68ced202b643053e9f281de52a016.jpg",
            title:"vbbvhjdbfhvbhf",
            caption:'bgvgvggvg',
            description:"nvbdvbshdvhsdvg",
            links:[
                {link:"hbvsdhbvhbdhfbvf", icon:<YouTube/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<LanguageIcon/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<GitHubIcon/>}

            ]
        },
        {
            tag:"react",
            image:"https://www.befunky.com/images/wp/wp-2016-03-blur-background-featured-1.jpg?auto=webp&format=jpg&width=880",
            title:"vbbvhjdbfhvbhf",
            caption:'bgvgvggvg',

            description:"nvbdvbshdvhsdvg",
            links:[
                {link:"hbvsdhbvhbdhfbvf", icon:<YouTube/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<LanguageIcon/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<GitHubIcon/>}

            ]
        },
        {
            tag:"python",
            image:"https://images.unsplash.com/photo-1579546929518-9e396f3cc809?ixlib=rb-1.2.1&w=1000&q=80",
            title:"vbbvhjdbfhvbhf",
            caption:'bgvgvggvg',

            description:"nvbdvbshdvhsdvg",
            links:[
                {link:"hbvsdhbvhbdhfbvf", icon:<YouTube/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<LanguageIcon/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<GitHubIcon/>}

            ]
        },
        {
            tag:"java",
            image:"https://www.geeklawblog.com/wp-content/uploads/sites/528/2018/12/liprofile-656x369.png",
            caption:'bgvgvggvg',
            title:"vbbvhjdbfhvbhf",
            description:"nvbdvbshdvhsdvg",
            links:[
                {link:"hbvsdhbvhbdhfbvf", icon:<YouTube/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<LanguageIcon/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<GitHubIcon/>}

            ]
        },
        {
            tag:"node",
            image:"https://media.istockphoto.com/photos/brown-wood-texture-dark-wooden-abstract-background-picture-id1137996207?k=6&m=1137996207&s=612x612&w=0&h=Eli8yvjTkBpkkT7QZj_hd2wbdKojeNHcxmo209SN1MM=",
            caption:'bgvgvggvg',
            title:"vbbvhjdbfhvbhf",
            description:"nvbdvbshdvhsdvg",
            links:[
                {link:"hbvsdhbvhbdhfbvf", icon:<YouTube/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<LanguageIcon/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<GitHubIcon/>}

            ]
        },
        {
            tag:"java",
            image:"https://cdn.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_960_720.jpg",
            caption:'bgvgvggvg',
            title:"vbbvhjdbfhvbhf",
            description:"nvbdvbshdvhsdvg",
            links:[
                {link:"hbvsdhbvhbdhfbvf", icon:<YouTube/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<LanguageIcon/>},
                {link:"hbvsdhbvhbdhfbvf", icon:<GitHubIcon/>}

            ]
        },
    ]
};